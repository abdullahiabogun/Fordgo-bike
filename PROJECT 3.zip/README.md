# (Ford go bike data exploration)
## by (Abdullahi Abogun)


## Dataset

This data set includes information about individual rides made in a bike-sharing system covering the greater San Francisco Bay area. It contains anonymized data of users for an approximate 183,000 trips, inluding duration and other attributes.

I had to convert duration in seconds to minutes to make the information more intuitive, and i also had to extract useful information such as time of day and day of week from the time variable given.


## Summary of Findings

Overall from the data we see typically rides take within 5 to 20 mins with an average of around 10 mins during the week and that number rises slightly during weekends. This uptick in minutes is majorly seen from customers rather than subscribers even though there are more subscribers than customers.During the course of the exploration we also see that majority of users are young adults and Thursday seem to be the most busy day of the week. 

Outside of the main varible we see the sizeable number of trips taken are by male young adults and this is driven by the number of them who are subscribers. 

## Key Insights for Presentation

For the presentation i will focus on just the interactions of key feautures day of week and how other sub feature such as usertype and age ditribution relate with them.

I will start by introducing the main feature,followed by the ditribution of trips across days of the week and then a box plot. I will also show briefly how the duration was distributed among the top and bottom 20 stations.The other 2 categorical variable user type and age distribution will then be plotted using point plot, as they clearly show interaction between the main variables.
I used different color palette to be able to differentiate the categorical variables.
